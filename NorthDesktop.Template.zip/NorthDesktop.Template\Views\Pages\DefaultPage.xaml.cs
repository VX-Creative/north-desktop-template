﻿namespace NorthDesktop.Template.Views.Pages
{
    public partial class DefaultPage : Page
    {
        // Mantem uma page minima para copiar ao criar novas telas.
        public DefaultPage()
        {
            InitializeComponent();
        }
    }
}

