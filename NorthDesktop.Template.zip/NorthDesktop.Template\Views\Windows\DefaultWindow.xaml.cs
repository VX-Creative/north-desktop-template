﻿namespace NorthDesktop.Template.Views.Windows
{
    public partial class DefaultWindow
    {
        // Mantem uma janela de referencia para novos fluxos do sistema.
        public DefaultWindow()
        {
            InitializeComponent();
        }
    }
}

