﻿# NorthDesktop.Framework

Pacote fechado gerado diretamente da codebase principal do North Desktop.

Use este pacote para distribuir a base compilada sem expor o código-fonte do shell.

