﻿namespace NorthDesktop.Template.Views.Pages
{
    public partial class DataPage : Page, INotifyPropertyChanged, INavigationAware
    {
        private bool _isInitialized;
        private IEnumerable<DataColor>? _colors;

        // Mantem a colecao visual usada pela grade de exemplo.
        public IEnumerable<DataColor>? Colors
        {
            get => _colors;
            private set
            {
                if (ReferenceEquals(_colors, value))
                {
                    return;
                }

                _colors = value;
                OnPropertyChanged();
            }
        }

        public DataPage()
        {
            DataContext = this;
            InitializeComponent();
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        public Task OnNavigatedToAsync()
        {
            if (!_isInitialized)
            {
                InitializePage();
            }

            return Task.CompletedTask;
        }

        public Task OnNavigatedFromAsync() => Task.CompletedTask;

        private void InitializePage()
        {
            // Gera os dados visuais apenas na primeira navegacao.
            var random = new Random();
            var colorCollection = new List<DataColor>();

            for (var i = 0; i < 8192; i++)
            {
                colorCollection.Add(
                    new DataColor
                    {
                        Color = new SolidColorBrush(
                            Color.FromArgb(
                                200,
                                (byte)random.Next(0, 250),
                                (byte)random.Next(0, 250),
                                (byte)random.Next(0, 250)
                            )
                        )
                    }
                );
            }

            Colors = colorCollection;
            _isInitialized = true;
        }

        // Mantem a notificacao de binding local.
        private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

