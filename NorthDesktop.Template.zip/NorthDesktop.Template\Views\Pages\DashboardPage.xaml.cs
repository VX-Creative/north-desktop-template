﻿namespace NorthDesktop.Template.Views.Pages
{
    public partial class DashboardPage : Page, INotifyPropertyChanged
    {
        private int _counter;

        // Expoe o contador usado pela pagina inicial.
        public int Counter
        {
            get => _counter;
            private set
            {
                if (_counter == value)
                {
                    return;
                }

                _counter = value;
                OnPropertyChanged();
            }
        }

        // Mantem o comando principal da pagina no code-behind.
        public ICommand CounterIncrementCommand { get; }

        public DashboardPage()
        {
            CounterIncrementCommand = new RelayCommand(OnCounterIncrement);
            DataContext = this;

            InitializeComponent();
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnCounterIncrement()
        {
            Counter++;
        }

        // Atualiza os bindings locais da pagina.
        private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

