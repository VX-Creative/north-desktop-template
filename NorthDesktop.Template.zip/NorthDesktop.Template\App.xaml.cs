﻿using NorthDesktop.Framework.Extensions;
using NorthDesktop.Template.Configuration;
using NorthDesktop.Template.Views.Pages;

namespace NorthDesktop.Template
{
    public partial class App : Application
    {
        // Mantem um log de bootstrap para diagnostico quando o log4net nao sobe.
        private static readonly string BootstrapLogPath = Path.Combine(
            AppContext.BaseDirectory,
            "logs",
            "error",
            "app-error.log");

        // Mantem os servicos centrais disponiveis no bootstrap.
        private static readonly ServiceCollection Services = new();

        // Garante que a aplicacao execute apenas uma instancia local.
        private static readonly Mutex SingleInstanceMutex = new(
            initiallyOwned: false,
            name: $"{Assembly.GetExecutingAssembly().GetName().Name}-single-instance");

        // Centraliza o logger principal da aplicacao.
        private static readonly ILog Log = LogManager.GetLogger(typeof(App));

        private ServiceProvider? _serviceProvider;
        private bool _singleInstanceLockAcquired;

        // Expoe as configuracoes carregadas no startup.
        public static AppSettings Settings { get; private set; } = new();

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            WriteBootstrapLog("Startup iniciado.");

            if (!TryAcquireSingleInstance())
            {
                MessageBox.Show(
                    "Ja existe uma instancia da aplicacao em execucao.",
                    ResolveApplicationName(),
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                Shutdown();
                return;
            }

            // Centraliza o tratamento de falhas nao tratadas da UI.
            DispatcherUnhandledException += OnDispatcherUnhandledException;

            try
            {
                WriteBootstrapLog("Configurando servicos.");
                ConfigureServices();

                WriteBootstrapLog("Inicializando log4net.");
                InitializeLog4Net();

                Log.Info("Iniciando a aplicacao");
                WriteBootstrapLog("Logger principal ativo.");

                var shellWindow = _serviceProvider!.GetRequiredService<INavigationWindow>();
                MainWindow = shellWindow as Window;
                shellWindow.ShowWindow();
                shellWindow.Navigate(typeof(DashboardPage));
                WriteBootstrapLog("Shell exibido com sucesso.");
            }
            catch (Exception exception)
            {
                WriteBootstrapLog("Falha durante o startup.", exception);
                TryLogFatal("Falha ao iniciar a aplicacao", exception);

                MessageBox.Show(
                    "Falha ao iniciar a aplicacao. Consulte os logs.",
                    ResolveApplicationName(),
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);

                Shutdown(-1);
            }
        }

        protected override void OnExit(ExitEventArgs e)
        {
            // Libera recursos do bootstrap no encerramento.
            _serviceProvider?.Dispose();

            if (_singleInstanceLockAcquired)
            {
                SingleInstanceMutex.ReleaseMutex();
            }

            SingleInstanceMutex.Dispose();
            base.OnExit(e);
        }

        private bool TryAcquireSingleInstance()
        {
            try
            {
                _singleInstanceLockAcquired = SingleInstanceMutex.WaitOne(TimeSpan.Zero, true);
                return _singleInstanceLockAcquired;
            }
            catch (AbandonedMutexException)
            {
                _singleInstanceLockAcquired = true;
                return true;
            }
        }

        private void ConfigureServices()
        {
            // Carrega a configuracao sempre a partir da pasta do executavel.
            var configuration = new ConfigurationBuilder()
                .SetBasePath(AppContext.BaseDirectory)
                .AddJsonFile("AppSettings.json", optional: false, reloadOnChange: false)
                .Build();

            Services.Clear();
            Services.AddSingleton<IConfiguration>(configuration);
            Services.Configure<AppSettings>(configuration.GetSection("Settings"));

            // Registra o shell fechado e apenas as paginas abertas do template.
            Services.AddNorthDesktopFramework(builder =>
            {
                builder
                    .UseApplicationTitle($"{ResolveApplicationName()} v{ResolveApplicationVersion()}")
                    .AddPage<DashboardPage>("Início", Wpf.Ui.Controls.SymbolRegular.Home24)
                    .AddPage<DataPage>("Dados", Wpf.Ui.Controls.SymbolRegular.DataHistogram24)
                    .AddPage<NorthDesktop.Framework.Views.Pages.SettingsPage>(
                        "Configurações",
                        Wpf.Ui.Controls.SymbolRegular.Settings24,
                        isFooter: true);
            });

            _serviceProvider = Services.BuildServiceProvider();
            Settings = _serviceProvider.GetRequiredService<IOptions<AppSettings>>().Value;
        }

        private static string ResolveApplicationName()
        {
            // Mantem o titulo alinhado ao nome tecnico definido no csproj do dev.
            var assembly = Assembly.GetEntryAssembly() ?? Assembly.GetExecutingAssembly();
            var assemblyName = assembly.GetName().Name;

            return string.IsNullOrWhiteSpace(assemblyName) ? "Aplicacao" : assemblyName;
        }

        private static string ResolveApplicationVersion()
        {
            // Prioriza a versao curta configurada no FileVersion do projeto do dev.
            var assembly = Assembly.GetEntryAssembly() ?? Assembly.GetExecutingAssembly();
            var fileVersion = assembly.GetCustomAttribute<AssemblyFileVersionAttribute>()?.Version;
            var informationalVersion = assembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion;
            var assemblyVersion = assembly.GetName().Version?.ToString();
            var rawVersion = fileVersion ?? informationalVersion ?? assemblyVersion;

            if (string.IsNullOrWhiteSpace(rawVersion))
            {
                return "0.0.0";
            }

            var normalized = rawVersion.Split('-', '+')[0];
            var numbers = normalized.Split('.');

            if (numbers.Length >= 3)
            {
                return $"{numbers[0]}.{numbers[1]}.{numbers[2]}";
            }

            if (numbers.Length == 2)
            {
                return $"{numbers[0]}.{numbers[1]}.0";
            }

            if (numbers.Length == 1)
            {
                return $"{numbers[0]}.0.0";
            }

            return "0.0.0";
        }

        private void InitializeLog4Net()
        {
            // Inicializa o log a partir do arquivo distribuido com a aplicacao.
            try
            {
                var configPath = Path.Combine(AppContext.BaseDirectory, "log4net.config.xml");
                WriteBootstrapLog($"Lendo configuracao log4net em: {configPath}");

                var logConfiguration = new XmlDocument();
                using var logConfigStream = File.OpenRead(configPath);
                logConfiguration.Load(logConfigStream);

                var repositoryAssembly = Assembly.GetEntryAssembly() ?? Assembly.GetExecutingAssembly();
                var repositoryName = repositoryAssembly.FullName;
                var log4NetElement = logConfiguration["log4net"]
                    ?? throw new InvalidOperationException("A secao log4net nao foi encontrada em log4net.config.xml.");

                var repository = LogManager.GetAllRepositories()
                    .FirstOrDefault(item => string.Equals(item.Name, repositoryName, StringComparison.Ordinal))
                    ?? LogManager.CreateRepository(
                        repositoryAssembly,
                        typeof(log4net.Repository.Hierarchy.Hierarchy));

                log4net.Config.XmlConfigurator.Configure(repository, log4NetElement);
                WriteBootstrapLog("log4net inicializado com sucesso.");
            }
            catch (Exception exception)
            {
                WriteBootstrapLog("Falha ao inicializar log4net.", exception);
                throw;
            }
        }

        private void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            WriteBootstrapLog("Erro nao tratado na UI.", e.Exception);
            TryLogError("Erro na aplicacao", e.Exception);

            MessageBox.Show(
                "Ocorreu um erro inesperado e a aplicacao sera encerrada.",
                ResolveApplicationName(),
                MessageBoxButton.OK,
                MessageBoxImage.Error);

            e.Handled = true;
            Shutdown(-1);
        }

        private static void TryLogFatal(string message, Exception exception)
        {
            // Evita perder erro quando o logger principal ainda nao esta pronto.
            try
            {
                Log.Fatal(message, exception);
            }
            catch (Exception logException)
            {
                WriteBootstrapLog("Falha ao gravar Fatal no log4net.", logException);
            }
        }

        private static void TryLogError(string message, Exception exception)
        {
            // Evita perder erro quando o logger principal ainda nao esta pronto.
            try
            {
                Log.Error(message, exception);
            }
            catch (Exception logException)
            {
                WriteBootstrapLog("Falha ao gravar Error no log4net.", logException);
            }
        }

        private static void WriteBootstrapLog(string message, Exception? exception = null)
        {
            // Garante diagnostico de startup mesmo sem infraestrutura de log pronta.
            try
            {
                var directoryPath = Path.GetDirectoryName(BootstrapLogPath);
                if (!string.IsNullOrWhiteSpace(directoryPath))
                {
                    Directory.CreateDirectory(directoryPath);
                }

                var line = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff}] {message}";
                if (exception is not null)
                {
                    line = $"{line}{Environment.NewLine}{exception}{Environment.NewLine}";
                }
                else
                {
                    line += Environment.NewLine;
                }

                File.AppendAllText(BootstrapLogPath, line);
            }
            catch
            {
                // Nao interrompe o fluxo caso o fallback tambem falhe.
            }
        }
    }
}

























































