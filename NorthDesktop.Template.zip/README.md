# Pacote de Entrega - North Desktop

Este pacote foi preparado para acelerar a criação de novos sistemas com a base padronizada North Desktop.

## Conteúdo do pacote

- `NorthDesktop.Template`: projeto aberto para desenvolvimento das funcionalidades do sistema.
- `packages`: pacote fechado com o shell base (`NorthDesktop.Framework`).

## Como iniciar

1. Abra `NorthDesktop.Template/NorthDesktop.Template.csproj` no Visual Studio.
2. Execute a restauração de pacotes NuGet.
3. Compile o projeto para validar o ambiente.

## Fluxo recomendado de desenvolvimento

1. Crie novas interfaces em `Views/Pages`.
2. Implemente regras e estados em `ViewModels/Pages`.
3. Registre as novas páginas no bootstrap de navegação.
4. Execute testes manuais do fluxo alterado.

## Observações importantes

- O shell base distribuído em `packages` não deve ser alterado diretamente.
- A customização do produto deve acontecer no projeto `NorthDesktop.Template`.
- Mantenha o padrão de nomes, estrutura e navegação para preservar consistência do ecossistema.

---

## 🧑‍💻 Autor(es)
- Marcus Vinícius Gaspar (**contato@marcusgaspar.com**)
