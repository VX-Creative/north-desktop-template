﻿namespace NorthDesktop.Resources
{
    public partial class Translations
    {
    }
}

