﻿namespace NorthDesktop.Template.Configuration
{
    // Reserva o contrato de configuração central da aplicação.
    public class AppSettings
    {
    }
}

