﻿namespace NorthDesktop.Template.Models
{
    public struct DataColor
    {
        public Brush Color { get; set; }
    }
}

